using ecommerce.Infraestrutura.Data;
using ecommerce.Infraestrutura.Repositorios;
using ecommerce.Dominio.Interfaces;
using ecommerce.Application.Services;

var builder = WebApplication.CreateBuilder(args);

// ==================================================================
// 1. CONFIGURA��O DA API
// ==================================================================
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// ==================================================================
// 2. PERSIST�NCIA (SIMULA��O)
// ==================================================================
// AddSingleton � CR�TICO aqui. Ele garante que a lista de dados
// fique viva na mem�ria RAM enquanto a API estiver rodando.
builder.Services.AddSingleton<AppDbContext>();

// ==================================================================
// 3. INJE��O DE DEPEND�NCIA - REPOSIT�RIOS (INFRASTRUCTURE)
// ==================================================================
builder.Services.AddScoped<IUsuarioRepository, UsuarioRepository>();
builder.Services.AddScoped<ICategoriaRepository, CategoriaRepository>();
builder.Services.AddScoped<IProdutoRepository, ProdutoRepository>();
builder.Services.AddScoped<ICarrinhoRepository, CarrinhoRepository>();
builder.Services.AddScoped<IPedidoRepository, PedidoRepository>();

// ==================================================================
// 4. INJE��O DE DEPEND�NCIA - SERVICES (APPLICATION)
// ==================================================================
builder.Services.AddScoped<UsuarioService>();
builder.Services.AddScoped<CategoriaService>();
builder.Services.AddScoped<ProdutoService>();
builder.Services.AddScoped<CarrinhoService>();
builder.Services.AddScoped<PedidoService>();

// ==================================================================
// 5. CONSTRU��O E PIPELINE
// ==================================================================
var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();